<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use App\Jobs\SendPatientReportingReminderJob;

class SendPatientReportingReminderCommand extends Command
{
    protected $signature = 'patient-reporting:reminder';

    protected $description = 'Send patient reporting reminder emails';

    public function handle()
    {
        $artDbName = DB::connection(config('database.default'))->getDatabaseName();

        $patientDbConnection = env('DB_SECOND_CONNECTION');

        $patientDbName = DB::connection($patientDbConnection)->getDatabaseName();

        $clinicTypes = [
            'ARTCLINIC',
            'ARTBANK',
            'ARTSURROGACY'
        ];

        foreach ($clinicTypes as $clinicType) {

            $clinics = DB::table(DB::raw("$artDbName.clinic_registration as c"))
                ->where('c.status',1)
                ->where('c.clinic_type',$clinicType)

                ->whereNotIn(
                    DB::raw('c.clinic_id COLLATE utf8mb4_unicode_ci'),
                    function($query) use($patientDbName,$clinicType){

                        $query->select(DB::raw('clinic_id COLLATE utf8mb4_unicode_ci'))
                            ->from(DB::raw("$patientDbName.patient_period_reporting_table"))
                            ->where('type_clinic',$clinicType);

                    }
                )

                ->whereNotExists(function($query){

                    $query->select(DB::raw(1))
                        ->from('patient_reporting_reminder_log as r')
                        ->whereColumn('r.clinic_id','c.clinic_id')
                        ->where('r.reminder_month',now()->format('Y-m'));

                })

                ->orderBy('c.clinic_id')

                ->limit(50)

                ->select(
                    'c.clinic_id',
                    'c.clinic_type',
                    'c.name',
                    'c.email'
                )

                ->get();

            foreach($clinics as $clinic){

                SendPatientReportingReminderJob::dispatch($clinic);

            }

        }

        $this->info('Reminder jobs dispatched successfully.');
    }
}