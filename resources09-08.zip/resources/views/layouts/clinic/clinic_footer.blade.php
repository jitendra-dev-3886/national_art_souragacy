<style nonce="{{$cspNonce}}">
  </style>  