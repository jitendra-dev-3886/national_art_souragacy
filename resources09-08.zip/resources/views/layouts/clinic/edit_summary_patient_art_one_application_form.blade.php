@extends('layouts.clinic.clinic_master')
@section('content')



<style nonce="{{$cspNonce}}">
    .color-csp-clinic-one{
    color: red;
    }
    .width-csp-clinic-two{
    width: 550px;
    }
    .width-csp-clinic-three{
        width: 48%;
    }
    .width-csp-clinic-four{
    width: 20%;  
    }
    .bc-bc-color-csp-clinic-five{
        background-color: #0b5ed7; border-color: #0b5ed7; color: white;
    }
    .step-indicator {
      display: flex;
      justify-content: center;
      gap: 10px;
      margin-bottom: 20px;
    }
    .indicator {
      width: 20px;
      height: 20px;
      border-radius: 50%;
      background-color: #e9ecef;
    }
    .indicator.active {
      background-color: #0d6efd;
    }
    .progress-bar {
        background-color: #0d6efd;;
    }
    .csp-readonlycolor {
        background-color: #e8eaec !important;
        font-weight: bold;
    }
  </style>


<div class="container-fluid">
    <div class="col-lg-12">
        <div class="card">       
            <div class="card-body">  
                @if (session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
@endif
@if (session('exists'))
    <script nonce="{{ $cspNonce }}">
        alert("{{ session('exists') }}");
    </script>
@endif
            <h3 class="card-title mb-5 text-primary">Reporting Format for ART Clinic (Level-I)</h3>            
              <form  method="POST" id="art_clin1" action="{{ route ('clinic.summary_patient_save_art_one_application_form_edit') }}" enctype="multipart/form-data">                             
                @csrf
                <input type="hidden" name="id" value="{{ $report->id }}">
                <div class="row">
                    @php
                    $currentYear = date('Y');
                    $currentQuarter = ceil(date('n') / 3);
                @endphp
        
              <div class="col-md-3">
                    <div class="mb-3">
                        <label class="form-label d-block">
                            <strong>a. Year and quarter</strong>
                        </label>
                        <div class="d-flex gap-3">
                            <div class="d-flex gap-3">
                                <input type="text" class="form-control widthfe-csp-clinic-one"  name="year" value="{{ $report->year }}" readonly>
                                <input type="hidden" class="form-control widthfe-csp-clinic-one"  name="quarter" value="{{ $report->quarter }}" readonly>
                                <input type="text" class="form-control widthfe-csp-clinic-one" value="{{ $report->quarterdesc->description }}" readonly>
                            </div>                            
                        </div>
                    </div>
                </div>                   
                    <div class="col-md-5">
                        <div class="mb-3">
                            <label class="text-label form-label"
                                for="validationCustomUsername"><strong>c. Name of the
                                    Clinic</strong>
                                </label>
                            <div class="input-group">
                                <input type="text" 
                                value="{{ $report->name_of_clinic }}"
                                   class="form-control" name="name_of_clinic" id="name_of_clinic"
                                    aria-describedby="name_of_clinic" placeholder="" readonly>
                            </div>
                            <span id="name_of_clinicID"
                                class="clr-csp-clinic-three">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label class="text-label form-label"
                                for="validationCustomUsername"><strong>b. Clinic Registration
                                    Number</strong></label>
                            <div class="input-group">
                                <input type="text"
                                    value="{{ $report->clinic_level1_reg_num }}"
                                    class="form-control" name="clinic_level1_reg_num"
                                    id="clinic_level1_reg_num" aria-describedby="clinic_level1_reg_num"
                                    placeholder="" data-validation="alphanumeric"
                                    data-validation-allowing="_" readonly>
                                  
                            </div>
                            <span id="clinic_level1_reg_numID"
                                class="clr-csp-clinic-three">
                        </div>
                    </div>
                   
                   
                    
                 
                </div>
                

                <div class="row">

                    <div class="row">
                    

                            <div class="mb-3 d-flex align-items-center">
                                <label for="ongoing_self_gametes" class="form-label me-3 widthff-csp-clinic-two" ><strong>d. Total Number of Patients undergoing IUI procedure (ongoing cases)</strong></label>
                               
                            </div>
                               <div class="mb-2 d-flex align-items-center">
                                <label for="ongoing_self_gametes" class="form-label me-3 width-csp-clinic-two" >d.1 Number of Married couples</label>
                     
                                </div>

                                <div class="mb-3 d-flex align-items-center">
                        <label for="ongoing_self_gametes" class="form-label me-3 width-csp-clinic-two" >d.1.a Using self-gametes</label>
                        <input type="number" class="form-control width-csp-clinic-four" id="no_ongoing_self_gametes" name="no_ongoing_self_gametes" value="{{ $report->no_ongoing_self_gametes ?? '' }}" required>
                    </div>
                              <div class="mb-3 d-flex align-items-center">
                        <label for="ongoing_donor_semen" class="form-label me-3 width-csp-clinic-two">d.1.b Using donor semen</label>
                        <input type="number" class="form-control width-csp-clinic-four"  id="no_ongoing_donor_semen" value="{{ $report->no_ongoing_donor_semen ?? '' }}" name="no_ongoing_donor_semen" required>
                    </div>

                       <div class="mb-3 d-flex align-items-center">
                        <label for="ongoing_self_gametes" class="form-label me-3 width-csp-clinic-two" ><strong>(d.1.a+d.1.b) Total Married Couples </strong></label>
                        <input type="number" class="form-control width-csp-clinic-four"  id="no_married_couples" value="{{ $report->no_married_couples ?? '' }}" name="no_married_couples"  placeholder="" readonly>
                    </div>
                    
                          <div class="mb-3 d-flex align-items-center">
                        <label for="ongoing_single_woman" class="form-label me-3 width-csp-clinic-two" >d.2 Single women (unmarried/widow/divorcee)</label>
                        <input type="number" class="form-control width-csp-clinic-four"id="no_ongoing_single_woman" value="{{ $report->no_ongoing_single_woman ?? '' }}" name="no_ongoing_single_woman" required>
                    </div>


                       <div class="mb-3 d-flex align-items-center justify-content-between">
                        <label for="ongoing_self_gametes" class="form-label me-3 width-csp-clinic-two"><strong>Total Patients Undergoing IUI d (d.1+d.2)</strong></label>
                        <input type="number" class="form-control width-csp-clinic-four"   id="no_patient_IUI_onoing" value="{{ $report->no_patient_IUI_onoing ?? '' }}" name="no_patient_IUI_onoing"  placeholder="" readonly>
                    </div>


                            <div class="mb-3 d-flex align-items-center">
                                <label for="ongoing_self_gametes" class="form-label me-3 widthff-csp-clinic-two"><strong>e. Total Number of Patients where IUI procedure has been completed</strong></label>
                               
                            </div>

                            <div class="mb-2 d-flex align-items-center">
                                <label for="ongoing_self_gametes" class="form-label me-3 widthff-csp-clinic-two" >e.1 Married couples</label>
                               
                            </div>
                            
                    <div class="mb-3 d-flex align-items-center">
                        <label for="completed_self_gametes" class="form-label me-3 width-csp-clinic-two" >e.1.a Using self-gametes</label>
                        <input type="number" class="form-control width-csp-clinic-four"  id="no_completed_self_gametes" value="{{ $report->no_completed_self_gametes ?? '' }}" name="no_completed_self_gametes" required>
                    </div>
                           
                    <div class="mb-3 d-flex align-items-center">
                        <label for="completed_oocytes_donor_semen" class="form-label me-3 width-csp-clinic-two" >e.1.b Using donor semen</label>
                        <input type="number" class="form-control width-csp-clinic-four"  id="no_completed_donor_semen" value="{{ $report->no_completed_donor_semen ?? '' }}" name="no_completed_donor_semen" required>
                    </div>
                    
                       <div class="mb-2 d-flex align-items-center">
                        <label for="ongoing_self_gametes" class="form-label me-3 width-csp-clinic-two" ><strong>(e.1.a+e.1.b) Total Married Couples</strong></label>
                        <input type="number" class="form-control width-csp-clinic-four"   id="no_married_couple" value="{{ $report->no_married_couple ?? '' }}" name="no_married_couple"  readonly>
                    </div>
                           
                       <div class="mb-3 d-flex align-items-center">
                        <label for="completed_single_woman" class="form-label me-3 width-csp-clinic-two">e.2 Single women (unmarried/widow/divorcee):</label>
                        <input type="number" class="form-control width-csp-clinic-four"  id="no_completed_single_woman" value="{{ $report->no_completed_single_woman ?? '' }}" name="no_completed_single_woman" required>
                    </div>
                    <div class="mb-3 d-flex align-items-center justify-content-between">
                        <label for="ongoing_self_gametes" class="form-label me-3 width-csp-clinic-two" ><strong>Total Patients completed IUI e (e.1+e.2)</strong></label>
                        <input type="number" class="form-control width-csp-clinic-four"   id="no_patient_IUI_completed" value="{{ $report->no_patient_IUI_completed ?? '' }}" name="no_patient_IUI_completed"  readonly>
                    </div>
                    
                    </div>
                    
                <div class="row">
                    <div class="col-md-4">                    
                       <button type="button" onclick="window.location.href='{{ route('clinic.clinicForm_list') }}'" class="btn me-2 btn btn-danger">Close</button>                            
                        <button type="submit" name="submit" id="btnSubmit" 
                        class="btn me-2 bc-bc-color-csp-clinic-five" >update</button>
                    </div>
                </div>
                
            </form>







</div>







    </div>
</div>
    </div>
</div>
</div>


<script nonce="{{ $cspNonce }}">

document.addEventListener('DOMContentLoaded', function () {
    // alert('test');
    const form = document.forms['art_clin1'];
    const alertedFields = new Set();

    if (form) {
        const inputs = form.querySelectorAll('input');

        inputs.forEach(function (input) {
            input.addEventListener('focus', function () {
                if (!alertedFields.has(input.name) && input.value.trim() === '') {
                    // Try 1: label with for= matching input id
                    let label = document.querySelector(`label[for="${input.id}"]`);

                    // Try 2: if no label found, check if input is inside a label (ancestor)
                    if (!label) {
                        let parent = input.parentElement;
                        while (parent) {
                            if (parent.tagName.toLowerCase() === 'label') {
                                label = parent;
                                break;
                            }
                            parent = parent.parentElement;
                        }
                    }

                    // Try 3: if still no label, try previous sibling label (common pattern)
                    if (!label) {
                        let prev = input.previousElementSibling;
                        while (prev) {
                            if (prev.tagName.toLowerCase() === 'label') {
                                label = prev;
                                break;
                            }
                            prev = prev.previousElementSibling;
                        }
                    }

                    // Get label text or fallback to input name
                    let fieldName = label ? label.innerText.trim() : input.name || 'This field';

                    // Remove trailing colon or asterisk if any (clean up)
                    fieldName = fieldName.replace(/[:*]$/, '').trim();

                    alert(`Please fill out: ${fieldName}`);
                    alertedFields.add(input.name);
                }
            });
        });
    }
});
</script>



{{-- 

<script>
    // Wait until the DOM is fully loaded
    document.addEventListener("DOMContentLoaded", function () {
        const form = document.getElementById("art_clin1");
        if (!form) {
            alert("Form with ID 'art_clin1' not found!");
            return;
        }

        form.addEventListener("submit", function (event) {
            alert("Test message"); // This should now work
            if (!validatesubmit()) {
                event.preventDefault(); // Block form submission if validation fails
            }
        });
    });

    function validatesubmit() {
        if (document.getElementById("yearSelect").value == "") {
            alert("Select Year");
            document.getElementById("yearSelect").focus();
            return false;
        }
        if (document.getElementById("quarterSelect").value == "") {
            alert("Select Quarter");
            document.getElementById("quarterSelect").focus();
            return false;
        }           
        if (document.getElementById("name_of_clinic").value == "") {
            alert("Enter the number");
            document.getElementById("name_of_clinic").focus();
            return false;
        } 
        if (document.getElementById("no_ongoing_donor_semen").value == "") {
            alert("Enter the number");
            document.getElementById("no_ongoing_donor_semen").focus();
            return false;
        } 
        if (document.getElementById("no_ongoing_single_woman").value == "") {
            alert("Enter the number");
            document.getElementById("no_ongoing_single_woman").focus();
            return false;
        } 
        if (document.getElementById("no_completed_self_gametes").value == "") {
            alert("Enter the number");
            document.getElementById("no_completed_self_gametes").focus();
            return false;
        } 
        if (document.getElementById("no_completed_donor_semen").value == "") {
            alert("Enter the number");
            document.getElementById("no_completed_donor_semen").focus();
            return false;
        }        
        if (document.getElementById("no_completed_single_woman").value == "") {
            alert("Enter the number");
            document.getElementById("no_completed_single_woman").focus();
            return false;
        }   
        var agree = confirm(
            "Kindly check and confirm all details before final submission. There is no provision for editing/correction once the form is submitted."
        );
        return agree;
    }
</script>
 --}}



   <script nonce="{{ $cspNonce }}">
    function updateIUICounts() {
        const selfGametes = parseInt(document.getElementById('no_ongoing_self_gametes').value) || 0;
        const donorSemen = parseInt(document.getElementById('no_ongoing_donor_semen').value) || 0;
        const singleWomen = parseInt(document.getElementById('no_ongoing_single_woman').value) || 0;
    
        const marriedCouples = selfGametes + donorSemen;
        const totalPatients = marriedCouples + singleWomen;
    
        document.getElementById('no_married_couples').value = marriedCouples;
        document.getElementById('no_patient_IUI_onoing').value = totalPatients;
    }
    
    // Attach listener
    document.querySelectorAll('#no_ongoing_self_gametes, #no_ongoing_donor_semen, #no_ongoing_single_woman')
        .forEach(input => input.addEventListener('input', updateIUICounts));

        function updateIUICountss() {
        const selfGametess = parseInt(document.getElementById('no_completed_self_gametes').value) || 0;
        const donorSemens = parseInt(document.getElementById('no_completed_donor_semen').value) || 0;
        const singleWomens = parseInt(document.getElementById('no_completed_single_woman').value) || 0;
    
        const marriedCoupless = selfGametess + donorSemens;
        const totalPatientss = marriedCoupless + singleWomens;
    
        document.getElementById('no_married_couple').value = marriedCoupless;
        document.getElementById('no_patient_IUI_completed').value = totalPatientss;
    }
    
    // Attach listener
    document.querySelectorAll('#no_completed_self_gametes, #no_completed_donor_semen, #no_completed_single_woman')
        .forEach(input => input.addEventListener('input', updateIUICountss));
    </script>
  <script nonce="{{ $cspNonce }}">
    document.addEventListener('DOMContentLoaded', function () {
        const yearSelect = document.getElementById('yearSelect');
        const quarterSelect = document.getElementById('quarterSelect');

        const today = new Date();
        const currentYear = today.getFullYear();
        const currentMonth = today.getMonth() + 1; // 1-based

        // Determine current financial quarter
        let currentFinQuarter;
        if (currentMonth >= 4 && currentMonth <= 6) {
            currentFinQuarter = 1; // Q1 (Apr-Jun)
        } else if (currentMonth >= 7 && currentMonth <= 9) {
            currentFinQuarter = 2; // Q2 (Jul-Sep)
        } else if (currentMonth >= 10 && currentMonth <= 12) {
            currentFinQuarter = 3; // Q3 (Oct-Dec)
        } else {
            currentFinQuarter = 4; // Q4 (Jan-Mar)
        }

        function filterQuarters() {
            const selectedYear = parseInt(yearSelect.value);

            Array.from(quarterSelect.options).forEach(option => {
                const qNum = parseInt(option.getAttribute('data-quarter'));

                if (!qNum || isNaN(selectedYear)) {
                    option.hidden = false;
                    return;
                }

                if (selectedYear === currentYear) {
                    // Show only current financial quarter
                    option.hidden = qNum !== currentFinQuarter;
                } else {
                    option.hidden = false;
                }
            });

            const selectedOption = quarterSelect.selectedOptions[0];
            if (selectedOption && selectedOption.hidden) {
                quarterSelect.selectedIndex = 0;
            }
        }

        yearSelect.addEventListener('change', filterQuarters);
        filterQuarters();
    });
</script>
  <script nonce="{{ $cspNonce }}">
    document.addEventListener('DOMContentLoaded', function () {
        const currentYear = new Date().getFullYear();
        const currentMonth = new Date().getMonth() + 1;
        const currentQuarter = Math.ceil(currentMonth / 3);

        const yearSelect = document.getElementById('yearSelect');
        const quarterSelect = document.getElementById('quarterSelect');

        yearSelect.addEventListener('change', function () {
            const selectedYear = parseInt(this.value);

            // Reset quarter selection
            quarterSelect.value = '';

            Array.from(quarterSelect.options).forEach(option => {
                if (!option.value) return; // Skip default

                const quarterNum = parseInt(option.value.replace('Q', ''));

                if (selectedYear < currentYear) {
                    // Show all quarters
                    option.style.display = 'block';
                } else if (selectedYear === currentYear) {
                    // Show only up to the current quarter
                    option.style.display = quarterNum <= currentQuarter ? 'block' : 'none';
                } else {
                    // Future year selected — hide all
                    option.style.display = 'none';
                }
            });
        });
    });
</script>
<script nonce="{{ $cspNonce }}">
    document.addEventListener('DOMContentLoaded', function () {
        const numberInputs = document.querySelectorAll('input[type="number"]');

        numberInputs.forEach(input => {
            input.setAttribute('min', '0');

            input.addEventListener('input', function () {
                if (this.value < 0) {
                    this.value = 0;
                }
            });
        });
    });
</script>





















<script nonce="{{ $cspNonce }}">
    // function validatesubmit() {
    //     if (document.getElementById("yearSelect").value == "") {
    //         alert("Select Year");
    //         document.getElementById("yearSelect").focus();
    //         return false;
    //     }
    //     if (document.getElementById("quarterSelect").value == "") {
    //         alert("Select Quarter");
    //         document.getElementById("quarterSelect").focus();
    //         return false;
    //     }           
    //     if (document.getElementById("no_ongoing_self_gametes").value == "") {
    //         alert("Enter the number");
    //         document.getElementById("no_ongoing_self_gametes").focus();
    //         return false;
    //     } 
    //     if (document.getElementById("no_ongoing_donor_semen").value == "") {
    //         alert("Enter the number");
    //         document.getElementById("no_ongoing_donor_semen").focus();
    //         return false;
    //     } 
    //     if (document.getElementById("no_ongoing_single_woman").value == "") {
    //         alert("Enter the number");
    //         document.getElementById("no_ongoing_single_woman").focus();
    //         return false;
    //     } 
    //     if (document.getElementById("no_completed_self_gametes").value == "") {
    //         alert("Enter the number");
    //         document.getElementById("no_completed_self_gametes").focus();
    //         return false;
    //     } 
    //     if (document.getElementById("no_completed_donor_semen").value == "") {
    //         alert("Enter the number");
    //         document.getElementById("no_completed_donor_semen").focus();
    //         return false;
    //     }        
    //     if (document.getElementById("no_completed_single_woman").value == "") {
    //         alert("Enter the number");
    //         document.getElementById("no_completed_single_woman").focus();
    //         return false;
    //     }   
    //     var agree = confirm(
    //         "Kindly check and confirm all details before final submission. There is no provision for editing/correction once the form is submitted."
    //     );
    //     if (agree) {
    
    //         return true;
    //     } else {
    //         return false;
    //     }
    //     return true;
    // }
    </script> 
@endsection