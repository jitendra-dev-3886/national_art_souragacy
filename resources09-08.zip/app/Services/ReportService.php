<?php

namespace App\Services;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Database\Connection;
use Carbon\Carbon;

class ReportService
{
    private Connection $secondDatabase;

    // 1. CLASS CONSTANTS
    private const TBL_ART = 'patient_artclinic';
    private const TBL_SURROGACY = 'patient_surrogacyclinic';
    private const TBL_BANK = 'patient_artbank';

    private const REPORT_SECTIONS = [
        'A. Submitted data' => [
            'art_patients_submitted'       => 'Patient records submitted by ART clinics',
            'bank_donors_submitted'        => 'Donor records submitted by ART banks',
            'surrogacy_patients_submitted' => 'Patient records submitted by Surrogacy clinics',
        ],
        'B. No. of married couples who have undergone' => [
            'married_iui'       => 'Married Couples IUI',
            'married_art'       => 'Married Couples ART Treatment',
            'married_surrogacy' => 'Surrogacy Couples Treatment',
        ],
        'C. No. of Single woman who have undergone:' => [
            'single_iui'       => 'Single woman IUI',
            'single_art'       => 'Single woman ART Treatment',
            'single_surrogacy' => 'Surrogacy Treatment',
        ],
        'D. Total No. of procedures undertaken:' => [
            'proc_iui_h' => 'Procedure Undertaken IUI (H)',
            'proc_iui_d' => 'Procedure Undertaken IUI (D)',
        ],
        'E. Total No. of IVF/ICSI procedures undertaken:' => [
            'ivf_icsi_self'  => 'IVF/ICSI Self gametes',
            'ivf_icsi_donor' => 'IVF/ICSI Donor gametes',
        ],
        'F. Total No. of Surrogacy procedures undertaken -' => [
            'surrogacy_self'  => 'Surrogacy Self gametes',
            'surrogacy_donor' => 'Surrogacy Donor gametes',
        ],
        'G. Cause of Infertility in ART Treatment:' => [
            'art_cause_male'        => 'Infertility in ART Treatment Male factor',
            'art_cause_female'      => 'Infertility in ART Treatment ART Female factor',
            'art_cause_unexplained' => 'Unexplained factors',
        ],
        'H. Medication Indication for Surrogacy Treatment:' => [
            'sur_ind_uterus'       => 'Uterus Abnormalities',
            'sur_ind_ivf_fail'     => 'Repeated IVF Failure',
            'sur_ind_preg_loss'    => 'Multiple Pregnancy Loss',
            'sur_ind_illness'      => 'Life Threatening Illness',
            'sur_ind_male'         => 'Male Factor',
        ],
        'I. Having Surviving Child' => [
            'sur_child_yes' => 'Having Surviving Child Yes',
            'sur_child_no'  => 'Having Surviving Child No',
        ],
        'J. Treatment Outcome (Pregnant/ Not Pregnant)' => [
            'outcome_art_preg'      => 'ART Treatment (Pregnant)',
            'outcome_art_not_preg'  => 'ART Treatment (Not Pregnant)',
            'outcome_sur_preg'      => 'Surrogacy Treatment (Pregnant)',
            'outcome_sur_not_preg'  => 'Surrogacy Treatment (Not Pregnant)',
        ], 
    ];

    private const SUBMITTED_RECORDS = [
        'art_patients_submitted'       => ['table' => self::TBL_ART],
        'bank_donors_submitted'        => ['table' => self::TBL_BANK],
        'surrogacy_patients_submitted' => ['table' => self::TBL_SURROGACY],
    ];

    private const STANDARD_RECORDS = [
        'married_iui'       => ['table' => self::TBL_ART, 'conditions' => ['case_of' => 'one', 'art_proc_undertaken' => 'intra-uterine insemination(IUI)']],
        'married_art'       => ['table' => self::TBL_ART, 'conditions' => ['case_of' => 'one']],
        'married_surrogacy' => ['table' => self::TBL_SURROGACY, 'conditions' => ['case_of' => 'one', 'treatment_type' => 'surrogacy']],
        'single_iui'       => ['table' => self::TBL_ART, 'conditions' => ['case_of' => 'two', 'art_proc_undertaken' => 'intra-uterine insemination(IUI)']],
        'single_art'       => ['table' => self::TBL_ART, 'conditions' => ['case_of' => 'two']],
        'single_surrogacy' => ['table' => self::TBL_SURROGACY, 'conditions' => ['case_of' => 'two', 'treatment_type' => 'surrogacy']],
        'proc_iui_h' => ['table' => self::TBL_ART, 'conditions' => ['types_of_treat' => 'ART Treatment using self gametes']],
        'proc_iui_d' => ['table' => self::TBL_ART, 'conditions' => ['types_of_treat' => 'ART Treatment using donor gametes']],
        'ivf_icsi_self'  => ['table' => self::TBL_ART, 'conditions' => ['art_proc_undertaken' => 'Intra-cytoplasmic sperm injection-Embryo transfer(ICSI-ET)', 'types_of_treat' => 'ART Treatment using self gametes']],
        'ivf_icsi_donor' => ['table' => self::TBL_ART, 'conditions' => ['art_proc_undertaken' => 'Intra-cytoplasmic sperm injection-Embryo transfer(ICSI-ET)', 'types_of_treat' => 'ART Treatment using donor gametes']],
        'surrogacy_self'  => ['table' => self::TBL_SURROGACY, 'conditions' => ['types_of_treat' => 'Surrogacy using own gametes']],
        'surrogacy_donor' => ['table' => self::TBL_SURROGACY, 'conditions' => ['types_of_treat' => 'Surrogacy using donor gametes']],
        'art_cause_male'        => ['table' => self::TBL_ART, 'conditions' => ['male_factor' => 'Y']],
        'art_cause_female'      => ['table' => self::TBL_ART, 'conditions' => ['female_factor' => 'Y']],
        'art_cause_unexplained' => ['table' => self::TBL_ART, 'conditions' => ['unexplained' => 'Y']],
        'sur_ind_uterus'    => ['table' => self::TBL_SURROGACY, 'conditions' => ['uterus_ab' => 'Y']],
        'sur_ind_ivf_fail'  => ['table' => self::TBL_SURROGACY, 'conditions' => ['ivf_failure' => 'Y']],
        'sur_ind_preg_loss' => ['table' => self::TBL_SURROGACY, 'conditions' => ['preg_loss' => 'Y']],
        'sur_ind_illness'   => ['table' => self::TBL_SURROGACY, 'conditions' => ['life_threat' => 'Y']],
        'sur_ind_male'      => ['table' => self::TBL_SURROGACY, 'conditions' => ['male_factor' => 'Y']],
        'sur_child_yes' => ['table' => self::TBL_SURROGACY, 'conditions' => ['num_pre_child' => 'Yes']],
        'sur_child_no'  => ['table' => self::TBL_SURROGACY, 'conditions' => ['num_pre_child' => 'No']],
        'outcome_art_preg'      => ['table' => self::TBL_ART, 'conditions' => ['treat_outcomes' => 'Pregnant']],
        'outcome_art_not_preg'  => ['table' => self::TBL_ART, 'conditions' => ['treat_outcomes' => 'Not Pregnant']],
        'outcome_sur_preg'      => ['table' => self::TBL_SURROGACY, 'conditions' => ['tratment_Outcome' => 'Pregnant']],
        'outcome_sur_not_preg'  => ['table' => self::TBL_SURROGACY, 'conditions' => ['tratment_Outcome' => 'Not Pregnant']],
    ];

    // 2. CONSTRUCTOR
    public function __construct()
    {
        $connectionName = config('database.second_connection_name', env('DB_SECOND_CONNECTION'));
        $this->secondDatabase = DB::connection($connectionName);
    }

    // Helper to get years dynamically from the constant
    public function getTargetYears(): array
    {
        $startYear = 2022; // The first year your system started
        $currentYear = (int) now()->year; // Automatically gets current year (e.g., 2026, 2027...)
        
        // Returns an array like [2024, 2025, 2026, 2027...]
        return range($startYear, $currentYear);
    }

    public function getSections(): array
    {
        $sections = [];
        $sectionId = 1;

        // 1. Load all standard sections
        foreach (self::REPORT_SECTIONS as $sectionName => $fields) {
            $section = [
                'id'     => $sectionId++,
                'name'   => $sectionName,
                'fields' => [],
            ];

            $fieldNo = 1;
            foreach ($fields as $code => $name) {
                $section['fields'][] = [
                    'code' => $code,
                    'name' => $fieldNo++ . '. ' . $name,
                ];
            }

            $sections[] = $section;
        }

        // 2. Dynamically build and append the 'K. Year' section
        $yearSection = [
            'id'     => $sectionId++,
            'name'   => 'K. Year',
            'fields' => [],
        ];

        foreach ($this->getTargetYears() as $year) {
            $yearSection['fields'][] = [
                'code' => (string) $year,
                'name' => (string) $year,
            ];
        }
        
        $sections[] = $yearSection;

        return $sections;
    }

    // 3. GENERATE & OPTIMIZED QUERIES
    public function generate(Request $request): array
    {
        $requestedFields = $request->input('fields', []);

        if (empty($requestedFields)) {
            return [];
        }

        // Separate fields into "Submitted" vs "Standard"
        $standardFields = array_intersect($requestedFields, array_keys(self::STANDARD_RECORDS));
        $submittedFields = array_intersect($requestedFields, array_keys(self::SUBMITTED_RECORDS));
        
        $years = $this->getTargetYears();
        $results = [];

        // Run batched queries for standard fields
        if (!empty($standardFields)) {
            $results = array_merge($results, $this->batchStandardQueries($standardFields, $years));
        }

        // Run individual queries for submitted fields
        foreach ($submittedFields as $field) {
            $results = array_merge($results, $this->countSubmittedData($field, self::SUBMITTED_RECORDS[$field], $years));
        }

        // Combine fields (Ignoring "2024", "2025" checkboxes so they don't break the UI rows)
        $validDataFields = array_merge($standardFields, $submittedFields);

        // Map back to the expected output format for the blade view
        return collect($validDataFields)->map(function (string $field) use ($results, $years) {
            
            // Build the year distribution array for the Blade view
            $yearlyData = [];
            foreach ($years as $year) {
                $yearlyData[$year] = (int) ($results["{$field}_{$year}"] ?? 0);
            }

            return [
                'code'  => $field,
                'title' => $this->getExactTitle($field),
                'count' => (int) ($results["{$field}_total"] ?? 0), // Overall grand total
                'years' => $yearlyData // Yearly breakdown: ['2024' => 100, '2025' => 100]
            ];
        })->toArray();
    }

    public function calculateAllDailyTotals(): array
    {
        $allStandardFields  = array_keys(self::STANDARD_RECORDS);
        $allSubmittedFields = array_keys(self::SUBMITTED_RECORDS);
        $years              = $this->getTargetYears();
        
        $results = [];

        // 1. Run batched query for all standard fields
        if (!empty($allStandardFields)) {
            $results = array_merge($results, $this->batchStandardQueries($allStandardFields, $years));
        }

        // 2. Run queries for all submitted data fields
        foreach ($allSubmittedFields as $field) {
            $results = array_merge($results, $this->countSubmittedData($field, self::SUBMITTED_RECORDS[$field], $years));
        }

        // 3. Format results:
        // - 'married_iui_total' -> mapped to 'married_iui' (Grand Total)
        // - 'married_iui_2024'  -> kept as 'married_iui_2024' (Yearly Count)
        $finalResults = [];
        foreach ($results as $key => $value) {
            $intValue = (int) $value;

            if (str_ends_with($key, '_total')) {
                $originalField = str_replace('_total', '', $key);
                $finalResults[$originalField] = $intValue;
            } else {
                $finalResults[$key] = $intValue; // Keeps keys like 'married_iui_2024' => 100
            }
        }

        return $finalResults;
    }

    public function getExactTitle(string $fieldCode): string
    {
        foreach (self::REPORT_SECTIONS as $fields) {
            if (isset($fields[$fieldCode])) {
                return $fields[$fieldCode];
            }
        }
        
        return Str::headline($fieldCode); 
    }

    private function batchStandardQueries(array $fields, array $years): array
    {
        $groupedByTable = [];
        $counts = [];

        foreach ($fields as $field) {
            $tableName = self::STANDARD_RECORDS[$field]['table'];
            $groupedByTable[$tableName][] = $field;
        }

        foreach ($groupedByTable as $tableName => $tableFields) {
            
            $isSecondDb = in_array($tableName, [self::TBL_ART, self::TBL_SURROGACY, self::TBL_BANK]);
            $dbConnection = $isSecondDb ? $this->secondDatabase : DB::connection();
            
            $query = $dbConnection->table($tableName);
            
            $selects = [];
            $bindings = [];

            foreach ($tableFields as $field) {
                $conditions = self::STANDARD_RECORDS[$field]['conditions'];
                
                $caseParts = [];
                $conditionBindings = [];

                foreach ($conditions as $column => $value) {
                    $caseParts[] = "`$column` = ?";
                    $conditionBindings[] = $value;
                }
                
                $caseString = implode(' AND ', $caseParts);
                
                // 1. Calculate Grand Total
                $selects[] = DB::raw("SUM(CASE WHEN $caseString THEN 1 ELSE 0 END) as `{$field}_total`");
                $bindings = array_merge($bindings, $conditionBindings); 
                
                // 2. Loop through years to calculate specific yearly totals
                foreach ($years as $year) {
                    $selects[] = DB::raw("SUM(CASE WHEN $caseString AND `year` = ? THEN 1 ELSE 0 END) as `{$field}_{$year}`");
                    $bindings = array_merge($bindings, $conditionBindings);
                    $bindings[] = $year; 
                }
            }

            // FIXED: Tell Laravel these are specifically "select" bindings so it doesn't break
            $query->select($selects)->addBinding($bindings, 'select');
            $result = (array) $query->first();
            
            $counts = array_merge($counts, array_map('intval', $result));
        }

        return $counts;
    }

    private function countSubmittedData(string $field, array $parameters, array $years): array
    {
        $tableName = $parameters['table'] ?? null;

        if (!$tableName) {
            return [];
        }

        $query = $this->secondDatabase->table("{$tableName} as pac")
            ->join('patient_period_reporting_table as pprt', 'pac.reporting_id', '=', 'pprt.id')
            ->where('pprt.status', 'Finished');

        // 1. Calculate Grand Total
        $selects = [
            DB::raw("COUNT(*) as `{$field}_total`")
        ];

        // 2. Calculate Specific Yearly Totals 
        foreach ($years as $year) {
            $yearInt = (int) $year;
            $selects[] = DB::raw("SUM(CASE WHEN pac.year = {$yearInt} THEN 1 ELSE 0 END) as `{$field}_{$yearInt}`");
        }

        $query->select($selects);

        // --- GENERATE READY-TO-RUN SQL ---
        $sql = $query->toSql();
        $bindings = $query->getBindings();
        
        // This replaces the '?' placeholders with your actual values (like 'Finished')
        foreach ($bindings as $binding) {
            $value = is_numeric($binding) ? $binding : "'" . addslashes($binding) . "'";
            $sql = preg_replace('/\?/', $value, $sql, 1);
        }

        // This will print the raw, copy-pasteable SQL on your screen and stop the app
        // ---------------------------------

        $result = (array) $query->first();
        
        return array_map('intval', $result);
    }


    public function saveDailyReportToDatabase(array $data = null, string $reportDate = null, $selectedYear = null): bool
    {
        // 1. Use passed data or calculate it
        $data = $data ?? $this->calculateAllDailyTotals();

        // dd($data);
        
        // 2. Use passed date or default to today
        $reportDate = $reportDate ?? now()->toDateString(); 

        $getValue = function($field) use ($data, $selectedYear) {
            if ($selectedYear) {
                // If a year IS selected (e.g. 2024), it gets $data['married_iui_2024'] -> 499
                return $data["{$field}_{$selectedYear}"] ?? 0;
            }
            // If NO year is selected, it gets the Grand Total $data['married_iui'] -> 3554
            return $data[$field] ?? 0; 
        };

        // Table 1: Submitted Data (NO 'year' column)
        DB::table('daily_report_submitted_records')->updateOrInsert(
            ['report_date' => $reportDate], 
            [
                'art_patients_submitted'       => $getValue('art_patients_submitted'),
                'bank_donors_submitted'        => $getValue('bank_donors_submitted'),
                'surrogacy_patients_submitted' => $getValue('surrogacy_patients_submitted'),
                'updated_at'                   => now(),
            ]
        );

        // Table 2: Procedures and Causes (NO 'year' column)
        DB::table('daily_report_procedures')->updateOrInsert(
            ['report_date' => $reportDate],
            [
                'married_iui'           => $getValue('married_iui'),
                'married_art'           => $getValue('married_art'),
                'married_surrogacy'     => $getValue('married_surrogacy'),
                'single_iui'            => $getValue('single_iui'),
                'single_art'            => $getValue('single_art'),
                'single_surrogacy'      => $getValue('single_surrogacy'),
                'proc_iui_h'            => $getValue('proc_iui_h'),
                'proc_iui_d'            => $getValue('proc_iui_d'),
                'ivf_icsi_self'         => $getValue('ivf_icsi_self'),
                'ivf_icsi_donor'        => $getValue('ivf_icsi_donor'),
                'surrogacy_self'        => $getValue('surrogacy_self'),
                'surrogacy_donor'       => $getValue('surrogacy_donor'),
                'art_cause_male'        => $getValue('art_cause_male'),
                'art_cause_female'      => $getValue('art_cause_female'),
                'art_cause_unexplained' => $getValue('art_cause_unexplained'),
                'updated_at'            => now(),
            ]
        );

        // Table 3: Indications and Outcomes (NO 'year' column)
        DB::table('daily_report_outcomes')->updateOrInsert(
            ['report_date' => $reportDate],
            [
                'sur_ind_uterus'       => $getValue('sur_ind_uterus'),
                'sur_ind_ivf_fail'     => $getValue('sur_ind_ivf_fail'),
                'sur_ind_preg_loss'    => $getValue('sur_ind_preg_loss'),
                'sur_ind_illness'      => $getValue('sur_ind_illness'),
                'sur_ind_male'         => $getValue('sur_ind_male'),
                'sur_child_yes'        => $getValue('sur_child_yes'),
                'sur_child_no'         => $getValue('sur_child_no'),
                'outcome_art_preg'     => $getValue('outcome_art_preg'),
                'outcome_art_not_preg' => $getValue('outcome_art_not_preg'),
                'outcome_sur_preg'     => $getValue('outcome_sur_preg'),
                'outcome_sur_not_preg' => $getValue('outcome_sur_not_preg'),
                'updated_at'           => now(),
            ]
        );

        return true;
    }
}