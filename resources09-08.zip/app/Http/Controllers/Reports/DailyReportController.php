<?php

namespace App\Http\Controllers\Reports;

use App\Http\Controllers\Controller;
use App\Services\ReportService;
use App\Models\Report\DailyReportSnapshot;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;




class DailyReportController extends Controller
{
    protected ReportService $reportService;

    public function __construct(ReportService $reportService)
    {
        $this->reportService = $reportService;
    }

    public function dailyReport()
    {

        $sections = $this->reportService->getSections();

        return view('reports.daily_report', compact('sections'));
    }

    public function dailyPreview(Request $request)
    {
        $requestedFields = $request->input('fields', []);
        $reportDate = $request->input('report_date', now()->toDateString());

        if (empty($requestedFields)) {
            return back()->withErrors(['fields' => 'Please select at least one field to generate the report.'])->withInput();
        }

        // 1. Calculate and save data
        $allDailyResults = $this->reportService->calculateAllDailyTotals();
        $this->reportService->saveDailyReportToDatabase($allDailyResults, $reportDate);

        // 2. Get sections and dynamic years
        $sections = $this->reportService->getSections();
        $dynamicYears = $this->reportService->getTargetYears(); 
        
        $groupedReport = [];

        foreach ($sections as $section) {
            // Skip the 'K. Year' section from appearing as a regular data table section if it's just meant for metadata
            if ($section['name'] === 'K. Year') {
                continue; 
            }

            $sectionData = [
                'name' => $section['name'],
                'items' => []
            ];

            foreach ($section['fields'] as $field) {
                // ONLY include the field if its code was checked in the form request
                if (in_array($field['code'], $requestedFields)) {
                    
                    $yearlyData = [];
                    foreach ($dynamicYears as $year) {
                        $yearlyData[$year] = (int) ($allDailyResults["{$field['code']}_{$year}"] ?? 0);
                    }

                    $sectionData['items'][] = [
                        'title' => $field['name'],
                        'count' => (int) ($allDailyResults[$field['code']] ?? 0),
                        'years' => $yearlyData
                    ];
                }
            }

            // ONLY add the section if the user checked at least one field inside this specific section
            if (count($sectionData['items']) > 0) {
                $groupedReport[] = $sectionData;
            }
        }

        return view('reports.daily_report_preview', [
            'groupedReport' => $groupedReport,
            'reportDate'    => $reportDate,
            'dynamicYears'  => $dynamicYears
        ]);
    }

    public function getDailyReport(Request $request)
    {
        // 1. Get Date (If not provided in request, find the latest record date automatically)
        $reportDate = $request->input('report_date');

        if (!$reportDate) {
            $latestRecord = DB::table('daily_report_submitted_records')->orderBy('report_date', 'desc')->first();

            $reportDate = $latestRecord ? $latestRecord->report_date : now()->toDateString();
        }

        // 2. Get Filters
        $requestedFields = $request->input('fields', []); 
        $showAllFields = empty($requestedFields);

        // 3. Fetch the row for that date from all three tables directly
        $submitted = DB::table('daily_report_submitted_records')->where('report_date', $reportDate)->first();
        $procedures = DB::table('daily_report_procedures')->where('report_date', $reportDate)->first();
        $outcomes = DB::table('daily_report_outcomes')->where('report_date', $reportDate)->first();
        $sections = $this->reportService->getSections();
        $dynamicYears = $this->reportService->getTargetYears(); 

        $groupedReport = [];

        // 4. Smart Helper to decode the database value (handles JSON or plain numbers)
        $getFieldData = function($fieldCode) use ($submitted, $procedures, $outcomes) {
            $rawValue = $submitted->$fieldCode ?? $procedures->$fieldCode ?? $outcomes->$fieldCode ?? 0;
            
            if (is_string($rawValue) && str_starts_with(trim($rawValue), '{')) {
                return json_decode($rawValue, true);
            }
            
            return [
                'total' => (int) $rawValue
            ];
        };

        // 5. Build the Array for the Blade View
        foreach ($sections as $section) {
            if ($section['name'] === 'K. Year') continue; // Skip metadata sections

            $items = [];

            foreach ($section['fields'] as $field) {
                // Check if admin filtered by specific parameters
                if ($showAllFields || in_array($field['code'], $requestedFields)) {
                    
                    $decodedData = $getFieldData($field['code']);
                    
                    // Loop through years to prevent undefined index errors in Blade
                    $yearlyData = [];
                    foreach ($dynamicYears as $year) {
                        $yearlyData[$year] = $decodedData[$year] ?? 0;
                    }

                    $items[] = [
                        'title' => $field['name'],
                        'count' => $decodedData['total'] ?? 0,
                        'years' => $yearlyData
                    ];
                }
            }

            if (!empty($items)) {
                $groupedReport[] = [
                    'name'  => $section['name'],
                    'items' => $items
                ];
            }
        }

        // 6. Pass it to the view exactly how the view expects it
        return view('reports.daily_report_preview', [
            'groupedReport' => $groupedReport,
            'reportDate'    => $reportDate,
            'dynamicYears'  => $dynamicYears
        ]);
    }

    public function viewHistoricalReport(Request $request)
    {
        $reportDate = $request->input('report_date'); 
        $selectedYears = $request->input('search_years', []); 

        if (!$reportDate) {
            $latestRecord = DB::table('daily_report_submitted_records')->orderBy('report_date', 'desc')->first();
            $reportDate = $latestRecord ? $latestRecord->report_date : now()->toDateString();
        }

        $submitted = DB::table('daily_report_submitted_records')->where('report_date', $reportDate)->first();
        $procedures = DB::table('daily_report_procedures')->where('report_date', $reportDate)->first();
        $outcomes = DB::table('daily_report_outcomes')->where('report_date', $reportDate)->first();

        $sections = $this->reportService->getSections();
        $allAvailableYears = $this->reportService->getTargetYears(); 

        $displayYears = !empty($selectedYears) 
            ? array_intersect($allAvailableYears, $selectedYears) 
            : $allAvailableYears;

        $groupedReport = [];

        $getFieldData = function($fieldCode) use ($submitted, $procedures, $outcomes) {
            $rawValue = $submitted->$fieldCode ?? $procedures->$fieldCode ?? $outcomes->$fieldCode ?? 0;
            
            if (is_string($rawValue) && str_starts_with(trim($rawValue), '{')) {
                return json_decode($rawValue, true);
            }
            
            return [
                'total' => (int) $rawValue
            ];
        };

        foreach ($sections as $section) {
            if ($section['name'] === 'K. Year') continue;

            $sectionData = [
                'name' => $section['name'],
                'items' => []
            ];

            foreach ($section['fields'] as $field) {
                $decodedData = $getFieldData($field['code']);
                
                $yearlyData = [];
                foreach ($displayYears as $year) {
                    $yearlyData[$year] = $decodedData[$year] ?? 0;
                }

                $sectionData['items'][] = [
                    'title' => $field['name'],
                    'count' => $decodedData['total'] ?? 0,
                    'years' => $yearlyData
                ];
            }

            if (count($sectionData['items']) > 0) {
                $groupedReport[] = $sectionData;
            }
        }

        return view('reports.historical_report', [
            'groupedReport' => $groupedReport,
            'reportDate'    => $reportDate,
            'dynamicYears'  => $displayYears 
        ]);
    }
}