<?php

namespace App\Http\Controllers\patientreportdashboards;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DynamicReportingController extends Controller
{
    public function dashboard()
    {
        return view('layouts.admin.reporting.dashboard');
    }
}